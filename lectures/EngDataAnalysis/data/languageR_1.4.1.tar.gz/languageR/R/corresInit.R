`corresInit` <-
function(data) new("corres", data=data)

